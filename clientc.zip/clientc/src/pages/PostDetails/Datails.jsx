import React, { Component } from 'react';
import {useParams} from 'react-router-dom';
import axios from 'axios';

function withParams(Component) {
    return props => <Component {...props} params={useParams()} />;
  }
 class Datails extends Component {

  constructor(props){
    super(props);

    this.state={
        postcom:[]
    };
}

componentDidMount(){

    const id = this.props.params;
   

    axios.get(`/postcom/${id}`).then((res) =>{
        if(res.data.success){
            this.setState({
                postcom:res.data.existingPosts
            });

           
        }
    });
}



render() {

    const {ogname, ogtype, ogemail, ogphone, ogaddress, ogdes} = this.state.postcom;
    return (
        <div>
            <h4>{ogname}</h4>
            <hr/>

            <dl className='row'>
                <dt className='col-sm-3'>Description</dt>
                <dd className='col-sm-9'>{ogdes}</dd>

                <dt className='col-sm-3'>Otherdetails</dt>
                <dd className='col-sm-9'>{ogtype}{ogemail}{ogphone}{ogaddress}</dd>
            </dl>
        </div>
    )
}
}
export default withParams(Datails);



