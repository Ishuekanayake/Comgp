import React, { Component } from 'react';
import { Link, useParams } from "react-router-dom";
import axios from 'axios';
import './Mygp.css';

// function Mygp() {
//   const { id } = useParams();
//   const postcom = postcom.find((p) => p._id === Number(id));
//   return (
//     <div>
//       {postcom.ogname}
//     </div>
//   );
// }

// export default Mygp;


export default class Mygp extends Component {


//   constructor(props){
//     super(props);
  
//     this.state={
//       postcom:[]
//     };
//   }

//   componentDidMount(){
//     this.retrievePosts();
//   }
  
//   retrievePosts(){
//     axios.get("/postcom/").then(res =>{
//       if(res.data.success){
//         this.setState({
//           postcom:res.data.existingPosts
//         });
//         console.log(this.state.postcom)
//       }
//     });
//   }

  



  render() {
    return (
      <React.Fragment>

        <div>
          <h4 className='h4'>Group Name</h4>
        </div>
        <div className='container'>
        <div className='row divm'>
          <div className='col-9 div1'>a</div>
          <div className='col-3 div2'>
            <div className='list-group v1'>
              <a href="/cpost" className='list-group-item list-group-item-action v2 shadow'>Create New Post</a>
            </div>
          </div>
        </div>
        </div>
    </React.Fragment>
    )
  }
}

