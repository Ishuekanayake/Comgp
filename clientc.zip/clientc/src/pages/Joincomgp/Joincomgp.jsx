import React, { Component } from 'react';
import axios from 'axios';
import './Joincomgp.css';

export default class Joincomgp extends Component {

constructor(props){
  super(props);

  this.state={
    postcom:[]
  };
}

componentDidMount(){
  this.retrievePosts();
}

retrievePosts(){
  axios.get("/postcom").then(res =>{
    if(res.data.success){
      this.setState({
        postcom:res.data.existingPosts
      });
      console.log(this.state.postcom)
    }
  });
}




//search --------------------------------------------------------------------------------
filterData(postcom,searchKey){


  const result = postcom.filter((postcom) =>
  postcom.ogname.toLowerCase().includes(searchKey)||
  postcom.ogtype.toLowerCase().includes(searchKey)
  )

  this.setState({postcom:result})
}



handleSearchArea = (e) =>{


  const searchKey = e.currentTarget.value;

  axios.get("/postcom").then(res =>{
    if(res.data.success){

      this.filterData(res.data.existingPosts,searchKey)
    }
  });


}





  render() {
    return (
      <div className="container">
        <div className='row'>
          <div>
          <h2 className='h2'>List of the community groups</h2>
          </div>
          <div>
            <input
            className="form-control"
            type="search"
            placeholder="Search"
            name="searchQue"
            onChange={this.handleSearchArea}>
            </input>
          </div>
        </div>

        <table className='table'>
          <thead>
            <tr>
              <th scope='col'>#</th>
              <th scope='col'>Organization Name</th>
              <th scope='col'>About the organization</th>
              <th scope='col'>Type of the organization</th>
              <th scope='col'>Other details</th>
              <th scope='col'>Action</th>
            </tr>
          </thead>
          <tbody>
          {this.state.postcom.map((postcom,index) =>(
              <tr key={index}>
                <th scope='row'>{index+1}</th>

                <td>
                    <a href={`/postcom/'${postcom._id}'`} style={{textDecoration:'none'}}>
                    {postcom.ogname}
                    </a>
                </td>

                <td>{postcom.ogdes}</td>
                <td>{postcom.ogtype}</td>
                <td>
                  {postcom.ogemail}<br/>
                  {postcom.ogphone}<br/>
                  {postcom.ogaddress}
                </td>
                <td>
                  <a className="btn btn-success" href={`/postcom/'${postcom._id}'`}>
                    <i className="fa-solid fa-trash-can-xmark"></i>&nbsp;View
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    )
  }
}



