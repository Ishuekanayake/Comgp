import Content from '../../Components/Content1/Content'
// import Admin from '../../Components/Admin/Admin'



import React, { Component } from 'react';

export default class Comhome extends Component {
  render() {
    return (
      <React.Fragment>
        <Content/>
        {/* <Admin/> */}
    </React.Fragment>
    )
  }
}

