import './Createcomgp.css'
import React, { Component } from 'react'
import axios from 'axios';

export default class Createcomgp extends Component {

constructor(props){
    super(props);
    this.state={
        ogname:"",
        ogtype:"",
        ogemail:"",
        ogphone:"",
        ogaddress:"",
        ogdes:""
    }
}

handleInputChange = (e) =>{
    const {name,value} = e.target;

    this.setState({
        ...this.state,
        [name]:value
    })
}

onSubmit = (e) =>{

    e.preventDefault();

    const {ogname,ogtype,ogemail,ogphone,ogaddress,ogdes} = this.state;

    const data ={
        ogname:ogname,
        ogtype:ogtype,
        ogemail:ogemail,
        ogphone:ogphone,
        ogaddress:ogaddress,
        ogdes:ogdes
    }

    console.log(data)

    axios.post("/postcom/save",data).then((res) =>{
        if(res.data.success){
            this.setState(
                {
                    ogname:"",
                    ogtype:"",
                    ogemail:"",
                    ogphone:"",
                    ogaddress:"",
                    ogdes:""
                }
            )
        }
    })


}


  render() {
    return (
        <React.Fragment>
        <div>
            <div className='container'>
                <form className='fm shadow p-5' method="POST" action="/post-feedback">

                    <div className='row'>
                        <div className='col-6'>
                            <label className='mb-5'>
                                Name of the organization:
                            </label><br/>                   
                            </div>
                            <div className='col-6'>
                            <label className='mb-5'>
                                <input className='mx-5' type="text" name="ogname" value={this.state.ogname} 
                                onChange={this.handleInputChange} />
                            </label><br/>                   
                        </div>
                    </div>
                    <div className='row'>
                        <div className='col-6'>
                            <label className='mb-5'>
                                Type of the organization:
                                <br/>
                                (Govenment or private)
                            </label><br/>                   
                            </div>
                            <div className='col-6'>
                            <label className='mb-5'>
                                <input className='mx-5' type="text" name="ogtype" value={this.state.ogtype}
                                onChange={this.handleInputChange} />
                            </label><br/>                   
                        </div>
                    </div>
                    <div className='row'>
                        <div className='col-6'>
                            <label className='mb-5'>
                                Email Address:
                            </label><br/>                   
                            </div>
                            <div className='col-6'>
                            <label className='mb-5'>
                                <input className='mx-5' type="ogemail" name="ogemail" value={this.state.ogemail}
                                onChange={this.handleInputChange} />
                            </label><br/>                   
                        </div>
                    </div>
                    <div className='row'>
                        <div className='col-6'>
                            <label className='mb-5'>
                            Contact Number:
                            </label><br/>                   
                            </div>
                            <div className='col-6'>
                            <label className='mb-5'>
                                <input className='mx-5' type="number" name="ogphone" value={this.state.ogphone}
                                onChange={this.handleInputChange} />
                            </label><br/>                   
                        </div>
                    </div>

                    <div className='row'>
                        <div className='col-6'>
                            <label className='mb-5'>
                                Adress:
                            </label><br/>                   
                        </div>
                        <div className='col-6'>
                            <label className='mb-5'>
                                <input className='mx-5' type="text" name="ogaddress" value={this.state.ogaddress} 
                                onChange={this.handleInputChange} />
                            </label><br/>                   
                        </div>
                    </div>

                    <div className='row'>
                        <div className='col-6'>
                            <label className='mb-5'>
                                Description:
                            </label><br/>                   
                        </div>
                        <div className='col-6'>
                            <label className='mb-5'>
                            <textarea name="ogdes" rows={4} cols={40} value={this.state.ogdes} 
                            onChange={this.handleInputChange} />
                            </label><br/>                   
                        </div>
                    </div>
                    <div className='in'>
                    <button className='btn btn-success' type='submit' style={{marginTop:'15px', paddingLeft:'100px', paddingRight:'100px'}} onClick={this.onSubmit}>Submit</button>
                    </div>


                
                </form>
            </div>

        </div>
    </React.Fragment>
    )
  }
}



