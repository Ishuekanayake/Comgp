import React, { Component } from 'react'; 
import axios from 'axios';
import './Createpost.css';

export default class Createpost extends Component {

constructor(props){
    super(props);
    this.state={
        title:"",
        cdes:"",
        cimg:""
    }
}

handleInputChange = (e) =>{
    const {name,value} = e.target;

    this.setState({
        ...this.state,
        [name]:value
    })
}

onSubmit = (e) =>{

    e.preventDefault();

    const {title,cdes,cimg} = this.state;

    const data ={
        title:title,
        cdes:cdes,
        cimg:cimg
    }

    console.log(data)

    axios.post("/cpost/save",data).then((res) =>{
        if(res.data.success){
            this.setState(
                {
                    title:"",
                    cdes:"",
                    cimg:""
                }
            )
        }
    })


}


  render() {
    return (
        <React.Fragment>
        <div><h4 className='h4'>Create new post here</h4></div>
        <div>
            <div className='container'>
                <form className='fm shadow p-5'>

                    <div className='row'>
                        <div className='col-6'>
                            <label className='mb-5'>
                                Title:
                            </label><br/>                   
                            </div>
                            <div className='col-6'>
                            <label className='mb-5'>
                                <input className='mx-5' type="text" name="title" value={this.state.ogname} 
                                onChange={this.handleInputChange} />
                            </label><br/>                   
                        </div>
                    </div>

                    <div className='row'>
                        <div className='col-6'>
                            <label className='mb-5'>
                                Description:
                            </label><br/>                   
                        </div>
                        <div className='col-6'>
                            <label className='mb-5'>
                            <textarea name="cdes" rows={4} cols={40} value={this.state.ogdes} 
                            onChange={this.handleInputChange} />
                            </label><br/>                   
                        </div>
                    </div>

                    <div className='row'>
                        <div className='col-6'>
                            <label className='mb-5'>
                                Image:
                            </label><br/>                   
                            </div>
                            <div className='col-6'>
                            <label className='mb-5'>
                                <input className='mx-5' type="text" name="cimg" value={this.state.ogname} 
                                onChange={this.handleInputChange} />
                            </label><br/>                   
                        </div>
                    </div>
                    
                    
                
                    <div className='in'>
                    <button className='btn btn-success' type='submit' style={{marginTop:'15px', paddingLeft:'100px', paddingRight:'100px'}} onClick={this.onSubmit}>Create Post</button>
                    </div>


                
                </form>
            </div>

        </div>
    </React.Fragment>
    )
  }
}



