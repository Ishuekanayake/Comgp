import React, { Component } from 'react'

export default class Newcreatedpost extends Component {
  render() {
    return (
      <div>Newcreatedpost</div>
    )
  }
}
