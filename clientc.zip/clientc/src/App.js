import React, { Component } from 'react';
import { BrowserRouter as Router, Routes, Route, } from 'react-router-dom';
import Header from './Components/header/header';
import Comhome from './pages/comHome/Comhome';
import Createcomgp from './pages/Createcomgp/Createcomgp';
import Joincomgp from './pages/Joincomgp/Joincomgp';
import Details from './pages/PostDetails/Datails'
import Mygp from './pages/Mygp/Mygp';
import Createpost from './pages/createpost/Createpost';


export default class App extends Component {
  render() {
    return (

      <React.Fragment>
      <Header/>
      <Router>
        <Routes>
          <Route path="/mygp" element={<Mygp />} />
          <Route path="/jcomgp" element={<Joincomgp />} />
          <Route path="/ccomgp" element={<Createcomgp />} />
          <Route path="/postcom/:id" element={<Details/>} />
          <Route path="/cpost" element={<Createpost/>} />
          <Route path="/" element={<Comhome />} />
        </Routes>
      </Router>
    </React.Fragment>
    )
  }
}