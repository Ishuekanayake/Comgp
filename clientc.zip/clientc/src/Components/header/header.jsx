import './header.css'
import logo from './logo.png';

import React, { Component } from 'react'

export default class header extends Component {
  render() {
    return (
        // Header *****************************************************************************

    <div className='mdiv'>

    <div className='row dv1 px-2'>
    <nav className="navbar navbar-expand-lg navbar-dark">
        <div className='col-6'>
        <a className="navbar-brand imd" href="/"><img className='imgl' src={logo} alt="logo"/></a>
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
        </button>
        </div>

        <div className="collapse navbar-collapse col-6" id="navbarSupportedContent">
            <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
                <a className="nav-link prof" href="/">Profile</a>
            </li>
            </ul>
        </div>
    </nav>
    </div>

    <div className='row container mt-4'>
        <nav className="navbar navbar-expand-lg navbar-dark">

            <div className="collapse navbar-collapse dv2" id="navbarSupportedContent">
                <ul className="navbar-nav mr-auto">
                <li className="nav-item active a1">
                    <a className="nav-link text-light" href="/">HOME<span className="sr-only"></span></a>
                </li>
                </ul>
                <ul className="navbar-nav mr-auto">
                <li className="nav-item active a1">
                    <a className="nav-link text-light" href="/">ABOUT<span className="sr-only"></span></a>
                </li>
                </ul>
                <ul className="navbar-nav mr-auto">
                <li className="nav-item active a1">
                    <a className="nav-link text-light" href="/">BLOG<span className="sr-only"></span></a>
                </li>
                </ul>
                <ul className="navbar-nav mr-auto">
                <li className="nav-item active a1">
                    <a className="nav-link text-light" href="/">CONTACT<span className="sr-only"></span></a>
                </li>
                </ul>
            </div>
        </nav>
    </div>
    <div className='row mt-5'><h1 className='text-light h1'>Community Group</h1></div>
</div>

// Header end**************************************************************************
    )
  }
}

