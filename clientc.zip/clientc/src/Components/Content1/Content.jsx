import './Content.css'
import axios from 'axios'
import img1 from './img1.png'
import img2 from './img2.png'
import img3 from './img3.png'
import img4 from './img4.png'

import React, { Component } from 'react'

export default class Content extends Component {


    constructor(props){
        super(props);
      
        this.state={
          postcom:[]
        };
      }
      
      componentDidMount(){
        this.retrievePosts();
      }
      
      retrievePosts(){
        axios.get("/postcom").then(res =>{
          if(res.data.success){
            this.setState({
              postcom:res.data.existingPosts
            });
            console.log(this.state.postcom)
          }
        });
      }



  render() {
    return (
        <React.Fragment>
        <div className='row'>
            <div className='col-3 dd1'>

                <div className='list-group v1'>
                    <a href="/jcomgp" className='list-group-item list-group-item-action v2 shadow'>+ View Community Group</a>
                </div>
                <div className='list-group v1'>
                    <a href="/ccomgp" className='list-group-item list-group-item-action v2 v2a shadow'>+ Create Community Group</a>
                </div>

                <h6 className='h6'>My Groups</h6>
                <hr className='hr'/>





                {/* <div className='list-group v1'>
                    <a href='/mygp' className='list-group-item list-group-item-action v2 shadow'>My School</a>
                </div> */}

                {this.state.postcom.map((postcom,index) =>(
                <div className='list-group v1'>
                    <a href='/mygp' className='list-group-item list-group-item-action v2 shadow' style={{textDecoration:'none'}}>
                    {postcom.ogname}
                    </a>
                </div>
            ))}





            </div>






            <div className='col-9 cdd2'>
                <img className='im' src={img1} alt='image1'/>
                <img className='im' src={img2} alt='image2'/>
                <img className='im' src={img3} alt='image3'/>
                <img className='im' src={img4} alt='image4'/>

            </div>
        </div>
    </React.Fragment>  
    )
  }
}
