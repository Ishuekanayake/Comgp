import React from 'react'
import './Admin.css'

export default function Admin() {
  return (
    <React.Fragment>
        <div className='container mt-5 mb-5 Adv1'>
            <h3 className='mb-5 Ah1'>Community group request</h3>
            <div className='list-group Aa1'>
                <a href="#" className='list-group-item list-group-item-action Aa2 shadow'>Students of Institute of technology univercity of moratuwa</a>
            </div>
            <div className='list-group Aa1'>
                <a href="#" className='list-group-item list-group-item-action Aa2 shadow'>Acadamic Staff of Institute of technology Univercity of moratuwa</a>
            </div>
            <div className='list-group Aa1'>
                <a href="#" className='list-group-item list-group-item-action Aa2 shadow'>Students of Ananda Mitreya Central College</a>
            </div>
        </div>
    </React.Fragment>
  )
}
